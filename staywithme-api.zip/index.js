const express = require('express')
const bodyParser = require('body-parser')
const morgan = require('morgan')
const {createClient} = require('@supabase/supabase-js')
const app = express()
const port = 3000
require('dotenv').config();

app.use(morgan('combined'));

app.use(bodyParser.urlencoded({extended: true}));
app.use(bodyParser.json());

app.listen(port, () => {
  console.log(`API listening on port ${port}`)
})

// Create a single supabase client for interacting with your database
const supabase = createClient(process.env.URL, process.env.API_KEY)
//console.log('Supabase Instance: ', supabase)

app.get('/', async (req, res) => {
    res.send("StayWithMe API")
})

app.get('/users', async (req, res) => {
    const { data, error } = await supabase
        .from('users')
        .select()

    if(data) res.send(data)
    else res.send(error)
})

app.post('/users/create', async(req, res) => {
    const { data } = await supabase
        .from('users')
        .select('email')
        .eq('email', req.body.email)

    if(data.length > 0) res.send("Email already exist")
    else {
        const { error } = await supabase
        .from('users')
        .insert(req.body)
        console.log(data)
        if(error) res.send(error)
        else res.send("New user created")
    }
})

app.get('/users/:id', async (req, res) => {
    const { data } = await supabase
        .from('users')
        .select()
        .eq('id', req.params.id)

    if(data.length > 0) res.send(data[0])
    else res.send("User does not exist")
})

app.post('/users/update', async (req, res) => {
    const { error } = await supabase
        .from('users')
        .update(req.body)
        .eq('id', req.body.id)

    if(error) res.send("User was not updated")
    else res.send("User was updated")
})